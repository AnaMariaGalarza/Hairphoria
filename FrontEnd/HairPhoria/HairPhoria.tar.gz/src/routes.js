export const routes = {
    home: "/",
    categories: "/categories",
    spaservices: "/spaservices",
    details: "/details",
    addservices: "/addservices",
  };