import HeaderAndSearchVideo from './components/HeaderAndSearchVideo'
import './index.css'
import { Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Footer from './components/Footer'
import SpaServices from './pages/SpaServices'

function App() {
  

  return (
    <div>
    <HeaderAndSearchVideo/>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path="/spaservices" element={<SpaServices/>}/>
    </Routes>
    <Footer/>
    </div>
  )
}

export default App