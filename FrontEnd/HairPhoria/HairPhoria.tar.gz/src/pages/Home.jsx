
import Categories from "../components/Categories.jsx"
import Recommended from "../components/Recommended.jsx"

const Home = () => {
    return (
        <div>
            <Categories />
            <Recommended />
        </div>
    )
}

export default Home