const DetailsService = () => {
    return (
        <div>DetailsService</div>
    )
}

export default DetailsService