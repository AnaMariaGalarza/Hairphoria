import CardSpaServices from "../components/CardSpaServices"

const SpaServices = () => {
    return (
        <CardSpaServices/>
    )
}

export default SpaServices