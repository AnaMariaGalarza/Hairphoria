import "../styles/Footer.css"
import logo from "../assets/logo/android-chrome-192x192.png"
import facebook from "../assets/socialMediaIcons/LogoFacebook.png"
import instagram from "../assets/socialMediaIcons/LogoInstagram.png"
import linkedin from "../assets/socialMediaIcons/LogoLinkedIn.png"
import twitter from "../assets/socialMediaIcons/LogoTwiter.png"
import wpp from "../assets/socialMediaIcons/LogoWassap.png"


const Footer = () => {
    return (
        <div className="footerContainer">
            <div className="logoCreditos">
            <img src={logo} alt="Logo HairPhoria" className="logo" />
            <span>© 2023</span>
            </div>
            <div className="socialMedia">
                <img src={facebook}/>
                <img src={instagram}/>
                <img src={linkedin}/>
                <img src={twitter}/>
                <img src={wpp}/>
                
            </div>
        </div>
    )
}

export default Footer