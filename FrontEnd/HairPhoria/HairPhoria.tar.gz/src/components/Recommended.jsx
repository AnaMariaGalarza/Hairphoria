import "../styles/Card.css";
import recDescanso from "../assets/seccionesImagenes/recomendados/KitDescanso.png"
import recMasaje from "../assets/seccionesImagenes/recomendados/KitMasajes.png"
import recSpaPremium from "../assets/seccionesImagenes/recomendados/KitSpaPremium.png"
import Peinados from "../assets/seccionesImagenes/recomendados/Peinados.png"




const Recommended = () => {
     const recomendados = [
         {
             title: 'Kit Descanso',
             img: recDescanso
         },
         {
             title: 'Kit Masaje',
             img: recMasaje
         },
         {
             title: 'Kit Spa Premuim',
             img: recSpaPremium
         },
         {
             title: 'Kit Peinados',
             img: Peinados
         },
     ];
    return (
        <div>
        <h2>Recomendados</h2>

        <div className="cardContainer">

             {recomendados.map ((card, index) => (
            <div key={index} className="card">    
                <h3 className="title">{card.title}</h3>
                <img className="img" src={card.img} alt="imagen Recommended" />
            </div>
            ))} 
        
        </div>

    </div>
    )
}

export default Recommended