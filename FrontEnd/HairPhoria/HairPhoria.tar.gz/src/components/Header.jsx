import "../styles/Header.css"
import img from "../assets/logo/android-chrome-192x192.png"
import { Link } from "react-router-dom"
import { routes } from "../routes.js"

const Header = () => {
    return (
        <div className="header">
            <div className="logo">
                <Link to={routes.home} className="link">  
                    <img className="imgLogo" src={img} alt="logo HairPhobia" />
                    <span className="linea-vertical"></span>
                    <span className="slogan">La felicidad del cabello</span>
                </Link> 
            </div>
            <div className="button">
                <Link to={"#"}><button>Crear cuenta</button></Link>
                <Link to={"#"}><button>Iniciar sesion</button></Link>
            </div>
        </div>
        
    )
}

export default Header