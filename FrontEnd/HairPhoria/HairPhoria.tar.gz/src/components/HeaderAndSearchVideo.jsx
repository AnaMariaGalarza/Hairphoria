import BarSearch from "./BarSearch"
import Header from "./header"
import video from '../assets/headerVideo/videoheader.mp4'
import '../styles/HeaderAndSearchVideo.css'

const HeaderAndSearchVideo = () => {
  return (
    <div className="headerContainer">
      <div className="video-container">
        <video src={video} autoPlay loop muted className="video"/>
        <div className="opacidad"></div>
      </div>
      <Header/>
      <BarSearch/>
    </div>
  )
}

export default HeaderAndSearchVideo