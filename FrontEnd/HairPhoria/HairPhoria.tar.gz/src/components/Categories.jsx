import "../styles/Card.css"
import corteDeCabelloCorto from "../assets/seccionesImagenes/categorias/Corte de Cabello corto.png"
import barberia from "../assets/seccionesImagenes/categorias/Barberia.png"
import corteDeCabelloLargo from "../assets/seccionesImagenes/categorias/CorteCabelloLargo.png"
import manicura from "../assets/seccionesImagenes/categorias/Manicure.png"
import maquillaje from "../assets/seccionesImagenes/categorias/Maquillaje.png"
import mascarillas from "../assets/seccionesImagenes/categorias/Mascarillas.png"
import spa from "../assets/seccionesImagenes/categorias/Spa.png"
import tintura from "../assets/seccionesImagenes/categorias/Titura.png"
import { routes } from "../routes"
import { Link } from "react-router-dom"

const Categories = () => {


    const cardCategorie = [
        {
            title: 'Corte de Cabello Corto',
            img: corteDeCabelloCorto
        },
        {
            title: "Barbería",
            img: barberia
        },
        {
            title: "Mascarillas",
            img: mascarillas
        },
        {
            title: "Tintura",
            img: tintura
        },
        {
            title: "Manicura",
            img: manicura
        },
        {
            title: "Spa",
            img: spa
        },
        {
            title: "Maquillaje",
            img: maquillaje
        },
        {
            title: "Corte de Cabello Largo",
            img: corteDeCabelloLargo
        }
    ]


    return (
        <div>
            <h2>Categorías</h2>

            <div className="cardContainer">

                {cardCategorie.map ((card, index) => (
                <div key={index} className="card"> 
                { card.title == "Spa" ? 
                (<Link to={routes.spaservices}>
                    <h3 className="titleSpa">{card.title}</h3>
                    <img className="img" src={card.img} alt="imagen categoria" />
                </Link>) : 
                (<>
                <h3 className="title">{card.title}</h3>
                <img className="img" src={card.img} alt="imagen categoria" />
                </>)
                }
                    
                </div>
                ))}
            
            </div>

        </div>
    )
}

export default Categories