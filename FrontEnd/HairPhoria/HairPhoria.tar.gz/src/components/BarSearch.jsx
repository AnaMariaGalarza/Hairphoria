import "../styles/BarSearch.css"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleChevronDown, faCalendarDay, faClock} from "@fortawesome/free-solid-svg-icons";
import DatePicker from "react-datepicker"
import "react-datepicker/dist/react-datepicker.css"
import { useState } from "react";



const BarSearch = () => {
    const [date, setDate] = useState({fecha: null});
    const [categoria, setCategoria] = useState("Categorias")
    const [profesional, setProfesional] = useState("Profesional")
    const [showInputFecha, setShowIFecha] = useState(true)
    const onChange = fecha => setDate({fecha: fecha})
    const onClickFecha = () => setShowIFecha(false)
    const onClickCategoria = () => setCategoria(event.target.innerText)
    const onClickProfesional = () => setProfesional(event.target.innerText)

    return (
        <div className="buscador">
            <span className="tituloSearch">Reserva tu cita para un día de mimos y cuidados</span>
            <nav className="nav">
                <ul className="elementSearch">
                    <li className="categorias"><a href="#"> <FontAwesomeIcon icon={faCircleChevronDown} className="icon"/> {categoria}</a>
                        <ul>
                            <li onClick={onClickCategoria}><a href="#">Peluqueria</a></li>
                            <li onClick={onClickCategoria}><a href="#">Barberia</a></li >
                            <li onClick={onClickCategoria}><a href="#">Cuidado facial</a></li >
                            <li onClick={onClickCategoria}><a href="#">Colorimetria</a></li >
                            <li onClick={onClickCategoria}><a href="#">Cuidado uñas</a></li >
                            <li onClick={onClickCategoria}><a href="#">SPA</a></li >
                            <li onClick={onClickCategoria}><a href="#">Maquillaje</a></li >
                            <li onClick={onClickCategoria}><a href="#">Cuidado cejas</a></li >
                            <li onClick={onClickCategoria}><a href="#">Cuidado pestañas</a></li>
                        </ul>
                    </li>
                    <li className="categorias"><a href="#"><FontAwesomeIcon icon={faCircleChevronDown} className="icon"/> {profesional}</a>
                        <ul>
                            <li onClick={onClickProfesional}><a href="#">Mayerly Avendaño</a></li>
                            <li onClick={onClickProfesional}><a href="#">Carlos Hernandez</a></li>
                            <li onClick={onClickProfesional}><a href="#">Nayelly Pantoja</a></li>
                            <li onClick={onClickProfesional}><a href="#">Yohana Zapata</a></li>
                            <li onClick={onClickProfesional}><a href="#">Ana Maria Galarza</a></li>
                            <li onClick={onClickProfesional}><a href="#">Gonzalo Volante</a></li>
                            <li onClick={onClickProfesional}><a href="#">Mario Volkmar</a></li>
                        </ul>
                    </li>
                    { showInputFecha ? 
                        (<li className="categorias" onClick={onClickFecha}>
                            <a href="#"><FontAwesomeIcon icon={faCalendarDay} className="icon"/>Fecha</a> 
                        </li>) : 
                        (<li> 
                            <div className="fecha">
                            <DatePicker selected={date.fecha} onChange={onChange}/>
                            </div>
                        </li>)
                    }
                    <li className="categorias"><a href="#"> <FontAwesomeIcon icon={faClock} className="icon"/> Check in - Check out</a></li>
                </ul>
            </nav>
        </div>
    )
}

export default BarSearch