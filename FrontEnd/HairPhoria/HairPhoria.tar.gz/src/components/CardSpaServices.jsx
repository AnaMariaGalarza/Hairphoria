import "../styles/Card.css"

import aventuraKid from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/AverturaDeSpaKid.png"
import cacao from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/CacaoRejuvenecedor.png"
import facialJapones from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/FacialJapones.png"
import masajesPie from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/MasajesPie.png"
import piedrasVolcanicas from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/PiedrasVolcanicas.png"
import renovacionProfunda from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/RenovacionProfunda.png"
import revitalizacionCapilar from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/RevitalizacionCapilar.png"
import ritualDelamor from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/RitualDelAmorParejas.png"
import diaRenovacion from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/DiaRenovacion.png"
import terapiaHidromasaje from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/TerapiaHidromasaje.png"
import tratamientoCapilar from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/TratamientoCapilar.png"
import tratamientoEstCapilar from "../assets/seccionesImagenes/categorias/servicios/serviciosSpa/TratamientoEstimulacionCapilar.png"


const CardSpaServices = () => {

    

    const spaServicios = [
        {
            title: 'Aventura de Spa kid',
            img: aventuraKid
        },
        {
            title: 'Cacao rejuvenecedor',
            img: cacao
        },
        {
            title: 'facial japones',
            img: facialJapones
        },
        {
            title: 'Masajes de pies',
            img: masajesPie
        },
        {
            title: 'Tratamiento de relajación con priedras volcánicas',
            img: piedrasVolcanicas
        },
        {
            title: 'Renovacion profunda',
            img: renovacionProfunda
        },
        {
            title: 'Revitalizacion capilar',
            img: revitalizacionCapilar
        },
        {
            title: 'Ritual del amor para parejas',
            img: ritualDelamor
        },
        {
            title: 'Dia de renovacion',
            img: diaRenovacion
        },
        {
            title: 'Terapia hidromasaje',
            img: terapiaHidromasaje
        },
        {
            title: 'Tratamiento capilar',
            img: tratamientoCapilar
        },
        {
            title: 'Tratamiento de estimulacion capilar',
            img: tratamientoEstCapilar
        }
    ];
    return (
        <div>
        <h2>SPA - Servicios</h2>

        <div className="cardContainer">
        
            {spaServicios.map ((card, index) => (
                <div key={index} className="card"> 
                    <h3 className="title">{card.title}</h3>
                    <img className="img" src={card.img} alt="imagen Spa Servicios" />
                </div>
                ))} 
        
            
        
        </div>

    </div>
    )
}

export default CardSpaServices